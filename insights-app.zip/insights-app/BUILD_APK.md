# Get the Insights APK (no Android Studio needed)

1. Create a free GitHub account and a new empty repository (private is fine).
2. Upload everything in this folder to it (drag and drop in the web page, or `git push`).
3. Open the repository's **Actions** tab, pick **Build Insights APK**, press **Run workflow**.
4. After about 20-40 minutes, open the finished run and download **Insights-apk** under Artifacts.
5. Unzip it, copy the `.apk` to your Android phone, tap it, and allow "Install unknown apps".

The APK is signed with the debug key, so it installs for testing but is not for the Play Store.
