export {VoiceBar} from './VoiceBar';
