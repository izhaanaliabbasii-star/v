export {PalPurchaseFooter} from './PalPurchaseFooter';
